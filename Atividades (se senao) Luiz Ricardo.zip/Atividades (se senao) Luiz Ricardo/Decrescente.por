programa {
  funcao inicio() {
    
    inteiro n1, n2, n3, numero

  
    escreva("Digite o primeiro número: ")
    leia(n1)
    escreva("Digite o segundo número: ")
    leia(n2)
    escreva("Digite o terceiro número: ")
    leia(n3)

   
    se (n1 < n2) {
      numero = n1
      n1 = n2
      n2 = numero
    }

   
    se (n1 < n3) {
      numero = n1
      n1 = n3
      n3 = numero
    }

    se (n2 < n3) {
      numero = n2
      n2 = n3
      n3 = numero
    }

    
    escreva("\nNúmeros em ordem decrescente: ", n1, ", ", n2, ", ", n3)
  }
}
  }
}
